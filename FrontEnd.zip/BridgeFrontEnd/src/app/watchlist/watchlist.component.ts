import { Component, OnInit } from '@angular/core';
import {FormControl} from '@angular/forms';
import {Observable, interval} from 'rxjs';
import {map, startWith, switchMap} from 'rxjs/operators';
import { StockIndex } from '../stock-index';
import {HttpClientServices} from '../http-client.service'
import { CurrentStock } from '../current-stock'
import { SaveStockComponent } from '../save-stock/save-stock.component';
import { DisplayStatsComponent } from '../display-stats/display-stats.component';
import { MatDialog } from '@angular/material'

@Component({
  selector: 'app-watchlist',
  templateUrl: './watchlist.component.html',
  styleUrls: ['./watchlist.component.css']
})
export class WatchlistComponent implements OnInit {
  myControl = new FormControl();
  stockIndices:StockIndex[] = []
  filteredOptions: Observable<StockIndex[]>;
  selectedIndex:string
  stocks:CurrentStock[]
  stocksObservable:Observable<any>
  constructor(private httpClient:HttpClientServices,private dialog: MatDialog) {
    this.httpClient.getIndices().subscribe(data=>{this.stockIndices = data})
   }

  ngOnInit() {
    
    this.filteredOptions = this.myControl.valueChanges
      .pipe(
        startWith<string | StockIndex>(''),
        map(value => typeof value === 'string' ? value : value.name),
        map(name => name ? this._filter(name) : this.stockIndices.slice() )
        
      );

     this.dynamicDisplay();
  }

  dynamicDisplay()
  {
    this.stocksObservable = interval(2000).pipe(startWith(0),switchMap(()=>this.httpClient.getUserRecommendations()))
  }

  displayFn(stock?: StockIndex): string | undefined {
    return stock?stock.name:undefined
  }

  setSelectedIndex(stock)
  {
    this.selectedIndex = stock.index
  }

  private _filter(name: string): StockIndex[] {
    const filterValue = name.toLowerCase();

    return this.stockIndices.filter(option => option.name.toLowerCase().indexOf(filterValue) === 0);
  }

  onSave(stock: CurrentStock) {
    this.dialog.open(SaveStockComponent, {
      data: { stock }
    });
  }
  onDisplayDetails(symbol){
    this.dialog.open(DisplayStatsComponent,{
      data:{ symbol },
    });
  }

  addStock()
  {
     
    this.httpClient.addStock(this.selectedIndex).subscribe(result=>{
      if(!result)
      {
        alert("Unable to add this stock or stock already exists")
      }
      else
      {
        alert("Stock added successfully")
      }
    })
  }

  deleteStock(stock:CurrentStock)
  {
     
    this.httpClient.deleteStock(stock.symbol).subscribe(result=>{
      if(!result)
      {
        alert("Unable to delete Stock")
      }
      else
      {
        alert("Stock removed successfully")
      }
      console.log(result);
      //this.stocks = this.stocks.filter(u => u != stock);
    })
  }

  getMarketState()
  {
    return this.httpClient.getMarketState();
  }
}
