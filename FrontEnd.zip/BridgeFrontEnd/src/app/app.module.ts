import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule , ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';
import { DisplayRecommendationsComponent } from './display-recommendations/display-recommendations.component';
import { TabsComponent } from './tabs/tabs.component';
import { SaveStockComponent } from './save-stock/save-stock.component';
import { MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field'
import { MatInputModule } from '@angular/material/input'
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DisplaySavedStockComponent } from './display-saved-stock/display-saved-stock.component';
import { WatchlistComponent } from './watchlist/watchlist.component';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { DisplayStatsComponent } from './display-stats/display-stats.component';
import { AuthGuardService } from './auth-guard.service'
import { PreventLoggedInAccessService } from './prevent-logged-in-access.service'

const routes: Routes = [{
  path: "login", component: LoginComponent, canActivate: [PreventLoggedInAccessService]
}, {
  path: "recommendations", component: DisplayRecommendationsComponent, canActivate: [AuthGuardService]
}, {
  path: "displaySavedStocks", component: DisplaySavedStockComponent, canActivate: [AuthGuardService]
}, {
  path: "watchlist", component: WatchlistComponent, canActivate: [AuthGuardService]
}, {
  path: "", redirectTo: "recommendations", pathMatch: "full", canActivate: [AuthGuardService]
}, {
  path: "", redirectTo: "login", pathMatch: "full", canActivate: [PreventLoggedInAccessService]
}
];
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DisplayRecommendationsComponent,
    TabsComponent,
    SaveStockComponent,
    DisplaySavedStockComponent,
    WatchlistComponent,
    DisplayStatsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    MatDialogModule,
    BrowserAnimationsModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatAutocompleteModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  entryComponents: [SaveStockComponent, DisplayStatsComponent]
})
export class AppModule { }
