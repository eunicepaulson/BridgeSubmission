import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthenticationService } from './authentication.service';
import { routerNgProbeToken } from '@angular/router/src/router_module';

@Injectable({
  providedIn: 'root'
})
export class PreventLoggedInAccessService implements CanActivate {

  constructor(private authenticationService:AuthenticationService, private router: Router) { }

  canActivate() {
    if(!this.authenticationService.isUserLoggedIn())
    return true;
    this.router.navigate(['']);
  return false;
  }
}
