import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplaySavedStockComponent } from './display-saved-stock.component';

describe('DisplaySavedStockComponent', () => {
  let component: DisplaySavedStockComponent;
  let fixture: ComponentFixture<DisplaySavedStockComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisplaySavedStockComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplaySavedStockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
