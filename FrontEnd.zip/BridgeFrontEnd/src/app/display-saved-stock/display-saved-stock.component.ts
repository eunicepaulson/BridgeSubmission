import { Component, OnInit } from '@angular/core';
import { HttpClientServices} from '../http-client.service'
import { SavedStock } from '../saved-stock';

@Component({
  selector: 'app-display-saved-stock',
  templateUrl: './display-saved-stock.component.html',
  styleUrls: ['./display-saved-stock.component.css']
})
export class DisplaySavedStockComponent implements OnInit {
  stocks: SavedStock[] = []
  constructor(private httpService: HttpClientServices) { }


  ngOnInit() {
    //subscribe to getSavedStocks() to get the saved stocks for the current user
    this.httpService.getSavedStocks().subscribe(
      data => {
        this.stocks = data; console.log(this.stocks.length);
      },
      err => {
        console.log("error in fetching data from :" + err.url)
      }
    )
  }

  //Deletes the selected row from the database and updates the variable stocks
  deleteStock(stock:SavedStock) {
    this.httpService.deleteSavedStock(stock).subscribe(data => {
      alert("Recommendation deleted successfully");
      this.stocks = this.stocks.filter(u => u != stock);
    })
  }

}
