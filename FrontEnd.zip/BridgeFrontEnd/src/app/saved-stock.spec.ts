import { SavedStock } from './saved-stock';

describe('SavedStock', () => {
  it('should create an instance', () => {
    expect(new SavedStock()).toBeTruthy();
  });
});
