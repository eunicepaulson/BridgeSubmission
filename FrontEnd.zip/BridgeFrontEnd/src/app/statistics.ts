export class Statistics {
    constructor(
        public prices:string,        
        public open:string,
        public low: string,
        public high:string,
        public prevClose:string,
        public fiftyTwoWeekHigh:string,
        public fiftyTwoWeekLow:string,
        public volume:string,
        public marketCap:string,
        public name:string,
        public dates:string
    )
    {

    }
}
