import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../authentication.service'
import { Router } from '@angular/router'
import {HttpClientServices} from '../http-client.service'
@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.css']
})
export class TabsComponent implements OnInit {

  constructor(private authService: AuthenticationService, private router: Router, private httpClient:HttpClientServices) { }

  ngOnInit() {
  }

  logout() {
    this.authService.logOut();
    this.httpClient.logout().subscribe();
    this.router.navigate(['login']);
  }

  isUserLoggedIn()
  {
    return this.authService.isUserLoggedIn();
  }

}
