import { Component, OnInit, Inject } from '@angular/core';
import { HttpClientServices } from '../http-client.service'
import { Statistics } from '../statistics'
import { MatDialogRef } from '@angular/material'
import { MAT_DIALOG_DATA } from '@angular/material';
import { Chart } from 'chart.js'


@Component({
  selector: 'app-display-stats',
  templateUrl: './display-stats.component.html',
  styleUrls: ['./display-stats.component.css']
})
export class DisplayStatsComponent implements OnInit {
  symbol: string
  NSEStats: Statistics
  BSEStats: Statistics
  chart = [];
  constructor(private httpService: HttpClientServices,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<DisplayStatsComponent>
  ) {
    this.NSEStats = new Statistics("", "", "", "", "", "", "", "", "", "", "");
    this.BSEStats = new Statistics("", "", "", "", "", "", "", "", "", "", "");
    this.symbol = data.symbol
  }

  ngOnInit() {
    this.displayStats();
  }

  //Displays the statistics for the selected stock
  displayStats() {
    //subscribe to getStats() to get retrieve the data to be displayed
    this.httpService.getStats(this.symbol).subscribe(
      data => {
        this.NSEStats = data[0];
        this.BSEStats = data[1]


        let NSE = [];
        NSE = JSON.parse(this.NSEStats.prices);
        let BSE = [];
        BSE = JSON.parse(this.BSEStats.prices);
        let dates = [];
        dates = JSON.parse(this.NSEStats.dates);
        
        //Converting dates to the required format
        let StatDates = []
        dates.forEach((res) => {
            let jsdate = new Date(res * 1000)
            StatDates.push(jsdate.toLocaleDateString('en', { year: 'numeric', month: 'short', day: 'numeric' }))
        })

        //plotting the graph for NSE prices and BSE prices with a 1 week interval for the last 52 weeks
        this.chart = new Chart('canvas', {
            type: 'line',
            data: {
              labels: StatDates,
              datasets: [
                { 
                  label:"NSE",
                  data: NSE,
                  borderColor: "#ff0000",
                  fill: false

                },
                { 
                  label:"BSE",
                  data: BSE,
                  borderColor: "#0000ff",
                  fill: false
                },
              ]
            },
            options: {
              legend: {
                display: true
              },
              scales: {
                xAxes: [{
                  display: true,
                  label:"Date"
                  
                }],
                yAxes: [{
                  display: true,
                  label:"Price"
                }],
              }
            }
          });

        })

  }
 
}
