import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Account } from './account';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  baseUrl:string;
  loggedAccount:Account;
  constructor(private httpClient: HttpClient) { 
    this.baseUrl = 'http://localhost:8080/';
  }
  public authenticate(account:Account)
  {
    return this.httpClient.get<Account>(this.baseUrl+'login/'+account.username+'/'+account.password).pipe(
      map(
        accInfo => {
          if(accInfo != null)
          {
         sessionStorage.setItem('username',accInfo.username);
         this.loggedAccount = accInfo;
         return accInfo;
          }
        }
      )
 
    );
  }

  isUserLoggedIn() {
    let user = sessionStorage.getItem('username')
    return !(user === null)
  }

  logOut() {
    sessionStorage.removeItem('username')
    this.httpClient.get<void>(this.baseUrl+'logout');
  }

  getUsername():string
{
  if(this.isUserLoggedIn())
  {
    return sessionStorage.getItem('username');
  }
  return "";

}

}
