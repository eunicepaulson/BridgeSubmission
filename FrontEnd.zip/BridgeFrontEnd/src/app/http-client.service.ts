import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CurrentStock } from './current-stock';
import { SavedStock } from './saved-stock'
import { Statistics} from './statistics'
import { StockIndex} from './stock-index'
import{map} from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class HttpClientServices {

  baseUrl:string;
  constructor(private httpClient: HttpClient) { 
    this.baseUrl = 'http://localhost:8080/';
  }

  getRecommendations()
  {
    return this.httpClient.get<CurrentStock[]>(this.baseUrl+"getRecommendations");
  }
  saveStock(stockDetails:SavedStock)
  {
    return this.httpClient.post<void>(this.baseUrl+"saveStock",stockDetails)
  }
  getSavedStocks()
  {
    return this.httpClient.get<SavedStock[]>(this.baseUrl+"getAllSavedStocks");
  }

  deleteSavedStock(stock)
  {
   return this.httpClient.post<void>(this.baseUrl+"deleteStock",stock);
  }
  getStats(symbol)
  {
    return this.httpClient.get<Statistics>(this.baseUrl+"getStatistics/"+symbol);
  
  }

  getIndices()
  {
    return this.httpClient.get<StockIndex[]>(this.baseUrl+"getAllIndices")
  }

  addStock(stockIndex:string)
  {
    console.log(stockIndex)
    return this.httpClient.post<Boolean>(this.baseUrl+"addUserStock",stockIndex)
  }

  deleteStock(stockIndex:string)
  {
    return this.httpClient.post<Boolean>(this.baseUrl+"deleteUserStock",stockIndex)
  }
  getUserRecommendations()
  {
    return this.httpClient.get<CurrentStock[]>(this.baseUrl+"getUserRecommendations")
  }

  logout()
  {
    return this.httpClient.get<void>(this.baseUrl+"logout")
  }

  getMarketState()
  {
    return this.httpClient.get<Boolean>(this.baseUrl+"marketState")
  }
}
