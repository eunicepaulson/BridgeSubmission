import { TestBed } from '@angular/core/testing';

import { PreventLoggedInAccessService } from './prevent-logged-in-access.service';

describe('PreventLoggedInAccessService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PreventLoggedInAccessService = TestBed.get(PreventLoggedInAccessService);
    expect(service).toBeTruthy();
  });
});
