export class CurrentStock {
    constructor(
       public symbol:string,
       public name:string,
       public nsePrice:number,
       public bsePrice:Number,
       public buyInExchange:string,
       public percentageDifference:number
    )
    {}
}
