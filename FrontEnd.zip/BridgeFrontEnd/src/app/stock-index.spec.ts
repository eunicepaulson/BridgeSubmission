import { StockIndex } from './stock-index';

describe('StockIndex', () => {
  it('should create an instance', () => {
    expect(new StockIndex()).toBeTruthy();
  });
});
