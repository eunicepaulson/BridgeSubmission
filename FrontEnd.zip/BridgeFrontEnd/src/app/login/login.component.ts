import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import {Account} from '../account';
import {Router} from '@angular/router';
import { invalid } from '@angular/compiler/src/render3/view/util';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  account:Account
  invalidLogin = false;
  constructor(private authService:AuthenticationService, private router:Router) { 
    this.account= new Account("","");
  }
 
  ngOnInit() {
  }
  authenticate()
  {
    this.authService.authenticate(this.account).subscribe(
      data => {
        if(data != null)
        {
        this.router.navigate(['recommendations'])
        this.invalidLogin = false;
        }
        else
        {
        this.invalidLogin = true;
        alert("Invalid username/password!");
        }
      },
      error => {
        this.invalidLogin = true;
        alert("Enter username/password !");


      }
    );
  }

  isUserLoggedIn()
  {
    return this.authService.isUserLoggedIn();
  }

  
}



