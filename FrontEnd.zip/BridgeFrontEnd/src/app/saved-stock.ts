import { CurrentStock} from './current-stock';
export class SavedStock extends CurrentStock {
    public id:string;    
    public noOfShares:number;
    public profit:number

     constructor(
       public symbol:string,
       public name:string,
       public nsePrice:number,
       public bsePrice:number,
       public buyInExchange:string,
       public percentageDifference:number,
       public dateSaved:string,
       public username:string   )
    {
        super(symbol,name,nsePrice,bsePrice,buyInExchange,percentageDifference);
    }
}
