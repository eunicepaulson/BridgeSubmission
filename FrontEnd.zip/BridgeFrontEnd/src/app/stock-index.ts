export class StockIndex {
    constructor(
        public name:string,        
        public index:string){}
}
