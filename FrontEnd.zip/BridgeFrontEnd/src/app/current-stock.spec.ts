import { CurrentStock } from './current-stock';

describe('CurrentStock', () => {
  it('should create an instance', () => {
    expect(new CurrentStock()).toBeTruthy();
  });
});
